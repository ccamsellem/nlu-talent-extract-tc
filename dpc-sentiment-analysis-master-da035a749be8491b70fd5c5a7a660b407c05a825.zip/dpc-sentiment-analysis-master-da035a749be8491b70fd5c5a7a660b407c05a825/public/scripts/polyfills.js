// todo: serve this file seperately and only load when needed...

// polyfills for Promise, Object.assign, etc.
import 'babel-polyfill';
// fetch polyfill for Safari / IE
// automatically sets global
import 'whatwg-fetch';
